import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLm1lZ2Fob3N0aW5ndHY=')

name = b.b64decode('TWVnYSBIb3N0aW5nIFRW')

host = b.b64decode('aHR0cDovL3ZvZGJveGlwdHYuZGRucy5uZXQ=')

port = b.b64decode('MjU0NjE=')