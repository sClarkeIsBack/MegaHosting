import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnd3bWVkaWFpcHR2')

name = b.b64decode('V1cgTWVkaWEgSVBUVg==')

host = b.b64decode('aHR0cDovL21lZ2Fob3N0aW5nLnphcHRvLm9yZw==')

port = b.b64decode('ODAwMA==')
