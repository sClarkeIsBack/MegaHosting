import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnd3bWVkaWFpcHR2')

name = b.b64decode('V1cgTWVkaWEgSVBUVg==')

host = b.b64decode('aHR0cDovL2ZvcmV2ZXJ0di5kZG5zLm5ldA==')

port = b.b64decode('ODAwMA==')
