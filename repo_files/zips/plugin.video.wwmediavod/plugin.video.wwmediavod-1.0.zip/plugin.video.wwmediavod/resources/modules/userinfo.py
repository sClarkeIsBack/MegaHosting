import base64

addon_name   = base64.b64decode('V1cgTWVkaWEgVk9E')
addon_id     = base64.b64decode('cGx1Z2luLnZpZGVvLnd3bWVkaWF2b2Q=')

host         = base64.b64decode('aHR0cDovL3d3dy52Ymhvc3RpbmcuY28udWs=')
port         = base64.b64decode('MjU0NjE=')